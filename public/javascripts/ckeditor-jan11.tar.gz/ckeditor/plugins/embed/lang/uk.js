CKEDITOR.plugins.setLang('embed', 'uk',
{
  embed : 
  {
    title : "Вставити embed",
    button : "Вставити embed",
    pasteMsg : "Будь ласка, вставте embed-код з Youtube, Myspace, Flickr та інших ресурсів в прямокутник, використовуючи (Ctrl+V), та нажміть OK."
  }
});
